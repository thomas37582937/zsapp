import React from 'react'
import { StyleSheet, View } from 'react-native'
import PropTypes from 'prop-types'

const Template = (props) => 
	<View>

	</View>

Template.propTypes = {

}

const styles = StyleSheet.create({

})

export default Template
