import Template from './Template'

export default Template
