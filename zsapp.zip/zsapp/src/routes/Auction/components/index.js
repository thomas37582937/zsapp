import headTime from './headTime.png'

export {
  headTime
}
