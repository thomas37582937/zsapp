import Content from './Content'
import Teacher from './Teacher'

export {
	Content,Teacher
}
