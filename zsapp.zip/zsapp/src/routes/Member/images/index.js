import back from './back.png'
import right from './right.png'
import accomplish from './accomplish.png'
import appointment from './appointment.png'
import head from './head.png'
import arrows from './arrows.png'
import enter from './enter.png'
import Merchants from './Merchants.png'
import mission from './mission.png'
import obligation from './obligation.png'
import participation from './participation.png'
import refund from './refund.png'
import store from './store.png'
import tutor from './tutor.png'



export {
  tutor, store, right, back, head, accomplish, appointment, arrows, enter, Merchants, mission, obligation, participation, refund
}