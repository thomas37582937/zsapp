import back from './back.png';
import home from './home.png';
import home_add from './home_add.png';
import right from './right.png';
import home_0 from './home_0.png';
import found from './found.png';
import found_0 from './found_0.png';
import goods_0 from './goods_0.png';
import mine from './Mine.png';
import mine_0 from './Mine_0.png';
import goods from './goods.png';
import avater from './avater.png';



export { avater, right, back, home, home_0, found, found_0, mine, mine_0, goods_0, home_add, goods }