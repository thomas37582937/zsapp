import CustomTabBar from './CustomTabBar'
export {
	CustomTabBar
}
