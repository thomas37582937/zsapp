import React from 'react'
import Tab from './Tab'
import Layout from '../../components/Layout'

// export default context => (
//   <Layout {...context}>
//     <Tab />
//   </Layout>
// )

export default Tab
