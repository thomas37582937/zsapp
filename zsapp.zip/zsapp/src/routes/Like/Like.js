import React, { Component } from 'react'
import { StyleSheet, View } from 'react-native'
import PropTypes from 'prop-types'

class Like extends Component {
	static propTypes = {

	}

	constructor(props) {
		super(props)
		this.state = {}
	}

	render() {
		return (
			<View>

			</View>
		)
	}
}

const styles = StyleSheet.create({

})

export default Like
