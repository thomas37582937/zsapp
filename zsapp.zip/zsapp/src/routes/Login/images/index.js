import loginPhone from './loginPhone.png'
import loginCode from './loginCode.png'
import loginPassword from './loginPassword.png'
import logo from './logo.png'
import weChatLogin from './weChatLogin.png'

export { loginPhone, loginCode, loginPassword, logo, weChatLogin }
