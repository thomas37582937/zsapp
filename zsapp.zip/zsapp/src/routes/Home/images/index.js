import button_orange from './button_orange.png'
import button_yellow from './button_yellow.png'
import eyes from './eyes.png'
import homeHeadButton0 from './homeHeadButton0.png'
import homeHeadButton1 from './homeHeadButton1.png'
import homeHeadButton2 from './homeHeadButton2.png'
import homeHeadButton3 from './homeHeadButton3.png'
import search from './search.png'

export {
  button_orange,
  button_yellow,
  eyes,
  homeHeadButton0,
  homeHeadButton1,
  homeHeadButton2,
  homeHeadButton3,
  search,
}
