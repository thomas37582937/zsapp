import Head from './Head'

export default Head
