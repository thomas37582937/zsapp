module.exports = {
  baseURL: 'http://192.168.0.103:3000', // 本地地址
}
