import { combineReducers } from 'redux'

import Common from './common'
import User from './user'

module.exports = combineReducers({
  Common,
  User,
})
